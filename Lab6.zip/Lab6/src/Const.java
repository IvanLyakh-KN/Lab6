public class Const {
    public static final String NAME_TABLE = "contacts";
    public static final String PERSON_ID = "id";
    public static final String PERSON_FIRST_NAME = "FirstName";
    public static final String PERSON_LAST_NAME = "LastName";
    public static final String PERSON_PHONE_NUMBER = "PhoneNumber";
}
